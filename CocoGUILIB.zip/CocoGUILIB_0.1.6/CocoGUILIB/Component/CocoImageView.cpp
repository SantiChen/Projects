/*
 * Copyright (c) 2012 Chukong Technologies, Inc.
 *
 * http://www.sweetpome.com
 * http://tools.cocoachina.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to permit
 * persons to whom the Software is furnished to do so, subject to the
 * following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
 * NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
 * USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include "CocoImageView.h"
#include "UISystem.h"
#include "DictionaryHelper.h"
#include "GUIScale9Sprite.h"

namespace cs {
    CocoImageView::CocoImageView():
    m_nViewType(1),
    m_nClickCount(0),
    m_fClickTimeInterval(0.0),
    m_bStartCheckDoubleClick(false),
    m_touchRelease(false),
    m_bDoubleClickEnable(false)
    {

    }
    
    CocoImageView::~CocoImageView()
    {
        
    }
    
    CocoImageView* CocoImageView::create()
    {
        CocoImageView* widget = new CocoImageView();
        if (widget && widget->init()) {
            return widget;
        }
        CC_SAFE_DELETE(widget);
        return NULL;
    }
    
    void CocoImageView::initNodes()
    {
        this->m_pCCRenderNode = cocos2d::CCSprite::create();
    }

    void CocoImageView::setTexture(const char* fileName,bool useSpriteFrame)
    {
        if (useSpriteFrame) {
            DYNAMIC_CAST_CCSPRITE->initWithSpriteFrameName(fileName);
        }else{
            DYNAMIC_CAST_CCSPRITE->initWithFile(fileName);
        }
        
    }
    
    void CocoImageView::setTextureRect(const cocos2d::CCRect &rect)
    {
        DYNAMIC_CAST_CCSPRITE->setTextureRect(rect);
    }
    
    bool CocoImageView::onTouchPressed(cocos2d::CCPoint &touchPoint)
    {
        this->setBeFocus(true);
        this->m_touchStartPos.x = touchPoint.x;
        this->m_touchStartPos.y = touchPoint.y;
        this->m_pWidgetParent->checkChildInfo(0,this,touchPoint);
        this->pushDownEvent();
        
        if (this->m_bDoubleClickEnable){
            this->m_fClickTimeInterval = 0;
            this->m_bStartCheckDoubleClick = true;
            this->m_nClickCount++;
            this->m_touchRelease = false;
        }
        return true;
    }
    
    bool CocoImageView::onTouchReleased(cocos2d::CCPoint &touchPoint)
    {
        if (this->m_bDoubleClickEnable){
            if (this->m_nClickCount >= 2){
                this->doubleClickEvent();
                this->m_nClickCount = 0;
                this->m_bStartCheckDoubleClick = false;
            }else{
                this->m_touchRelease = true;
            }
        }else{
            CocoWidget::onTouchReleased(touchPoint);
        }
        return true;
    }
    
    void CocoImageView::doubleClickEvent()
    {
        
    }
    
    void CocoImageView::checkDoubleClick(float dt)
    {
        if (this->m_bStartCheckDoubleClick){
            this->m_fClickTimeInterval += dt;
            if (this->m_fClickTimeInterval >= 200 && this->m_nClickCount > 0){
                this->m_fClickTimeInterval = 0;
                this->m_nClickCount--;
                this->m_bStartCheckDoubleClick = false;
            }
        }else{
            if (this->m_nClickCount <= 1){
                if (this->m_touchRelease){
                    this->releaseUpEvent();
                    this->m_fClickTimeInterval = 0;
                    this->m_nClickCount = 0;
                    this->m_touchRelease = false;
                }
            }
        }
    }
    
    void CocoImageView::setDoubleClickEnable(bool able)
    {
        if (able == this->m_bDoubleClickEnable){
            return;
        }
        this->m_bDoubleClickEnable = able;
        if (able){
            COCOUISYSTEM->getUIInputManager()->addCheckedDoubleClickWidget(this);
        }else{
            
        }
    }
    
    void CocoImageView::setFlipX(bool flipX)
    {
        DYNAMIC_CAST_CCSPRITE->setFlipX(flipX);
    }
    
    void CocoImageView::setFlipY(bool flipY)
    {
        DYNAMIC_CAST_CCSPRITE->setFlipY(flipY);
    }
    
    void CocoImageView::setDisplayFrame(cocos2d::CCSpriteFrame *pNewFrame)
    {
        DYNAMIC_CAST_CCSPRITE->setDisplayFrame(pNewFrame);
    }
}