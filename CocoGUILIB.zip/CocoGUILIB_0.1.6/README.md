
20130510 CocoGUILIB_v0.1.2

1. Added support for setting Anchor of UI widgets manually.
2. Added support for alpha action.
3. Added support for action of fading in/out.
4. Added support for android. 